"""Utilidades matematicas del laboratorio."""
